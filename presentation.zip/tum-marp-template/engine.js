const markdownItFa = require('markdown-it-fontawesome');
const markdownItContainer = require('markdown-it-container');
// // Create the extended Marpit instance
// const marpit = new Marpit().use(markdownItContainer, 'columns')

// // Setting default theme for styling multi-column
// marpit.themeSet.default = marpit.themeSet.add(`
// /* @theme custom-container */
// section { padding: 50px; }
// .columns { column-count: 2; }
// `)

module.exports = ({ marp }) => marp.use(markdownItContainer, 'columns');
