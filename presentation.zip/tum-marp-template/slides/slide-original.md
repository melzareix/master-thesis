---
title: Efficient Code Generation for Regular Expressions
description: Efficient Code Generation for Regular Expressions
_class:
  - lead
footer: Efficient Code Generation for Regular Expressions | Mohamed Elzarei
_footer: ""
paginate: true
_paginate: false
marp: true
inlineSVG: false
auto-scaling: false
---

# Efficient Code Generation for Regular Expressions

Supervisor: Prof. Dr. Thomas Neumann

Advisor: M.Sc. Philipp Fent

Mohamed Elzarei

---

## Outline

- Introduction
- Implementation
- Evaluation
- Future Work

---

## Introduction

- Regular Expressions.
   - Many data-intensive applications: NLP, Graphs and Data Mining.
* Regular Expressions Engines (e.g., RE2, Boost, PCRE)
   - Compile RegExp to an internal representation (DFA vs Backtracking).
   - Most are interpreted engines ⟶ Memory Indirection, Data not kept in CPU registers.
* Code-generation
   - Large Datasets ⟶ Amortizes the costs of compilation.
   - LLVM ⟶ Portable and efficient.
* Research Question ⟶ Is a code-generating RegExp engine performant?
   - Prototype DFA Based Engine.
   - Compare performance vs other engines.
---

## System Architecture

- Modular Architecture.
- CLI to interact with engine.

![bg right:50% 80%](images/sa.png)

---

## Parser (1)

- Generated Parser by ANTLR4.
- SQL-Compliant based on Firebird [1].

```ebnf
regex: alternation EOF;
alternation: expression ('|' expression)*;
expression: element*;
element: atom quantifier?;
quantifier: '*' | '+' | '?' | '{' number (',' (number)?)? '}';
number: INT+;
atom: character | characterClass | Wildcard | '(' alternation ')';
character: regularCharacter | EscapeChar specialChar;
characterClass: '_' | '[' classMember+ ']' | '[^' classMember+ ']';
classMember: character | range | predefinedClass;
range: character '-' character;
predefinedClass: '[:' predefinedClassName ':]';
predefinedClassName: 'ALPHA'| 'UPPER'| 'LOWER'| 'DIGIT'| 'ALNUM'| 'SPACE'| 'WHITESPACE';
regularCharacter: UnicodeLetter | INT;
specialChar: '*' | '+' | Newline | '?' | '[' | ']' |
             '{' | '}' | '^' | '-' | '_' | '|' | '( |' |  ')' |  '%' |  '\\';
```
---

## Parser (2)

<div class="center">

![width:600](images/parsetree.png)

</div>

---

## DFA Generator

<div class="center">

![width:250px](images/dfasa.png)

</div>

---

## Regular Expression to NFA (1)

:::columns

- Thompson’s construction Algorithm [2].
- Set of rules for conversion of each sub-expression.

![](images/parsetree.png)
:::

---

## Regular Expression to NFA (2)

1. Literals (e.g., **a**) <br />
   ![width:350](images/tc1.png)
2. Alternation or Positive Character Classes (e.g., **a|x**, **[ax]**) <br /><br />
   :::columns
   ![width:350](images/tc1.png) <br />
   ![width:350](images/tc3.png)

   ![width:350](images/tc2.png) <br />
   ![width:300](images/tc4.png)
   :::

---

## Regular Expression to NFA (3)

3. Concatenation (e.g., **abc**) <br />
   ![width:700](images/tc5.png)
4. Negative Character Classes (e.g., **[^ax]**)
   equivalent to **(\_ & (~[ax]))** <br />

   :::columns
   ![width:400](images/tc6.png) <br />
   ![width:400](images/tc7.png)

   ![width:600](images/tc8.png)
   :::

---

## Regular Expression to NFA (4)

5. Kleene Star (e.g., **a\***)
   ![width:350](images/tc10.png)
6. Plus Quantifier (e.g., **a+**)
   ![width:550](images/tc12.png)
7. Optional Quantifier (e.g., **a?**) <br />
   ![width:350](images/tc9.png)
---

## Regular Expression to NFA (4)
8. Counting Quantifier (e.g., **a{1,3}**) <br />
   ![width:800](images/tc13.png)
---

## NFA to DFA (1)
:::columns
- Powerset Construction Algorithm.
- Example: **xyz|xya**.

- Modifications
   - No Epsilon ⟶ Removed during NFA Construction.

![](images/nfatodfa1.png) <br />
![](images/nfatodfa2.png)
:::

---

## NFA to DFA (2)

- Modifications
   - No Epsilon ⟶ Removed during NFA Construction.
   - *Transitions are ranges* ⟶ Converted to non overlapping segments.

:::columns
![height:250](images/nfadfa3.png)

![height:350](images/nfadfa4.png)
:::

---

## DFA Minimization
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

- **Unreachable states** : Not reachable from start state.
- **Dead States** : No final state is reachable from this state.
- **Nondistinguishable states** ⟶ cannot be distinguished from one another for input.
---

## Code Generation (1)

- DFA ⟶ Efficient Machine Code.
- Two backends: C++ and LLVM.
   - C++: Easy to write & debug.
   - LLVM: Much Faster Compilation.

- Example: **[a-z][0-9]**

<div class="center">

   ![height:100](images/cg1.png)

</div>

---

## Code Generation (2)

```cpp
class FiniteAutomaton {
    public:
        bool deterministic;
        std::shared_ptr<FiniteAutomatonState> initial_state;
}
class FiniteAutomatonState {
    public:
        uint32_t id;
        bool accept;
        std::unordered_set<FiniteAutomatonTransition> transitions;
}
class FiniteAutomatonTransition {
    public:
        uint32_t min, max;
        std::shared_ptr<FiniteAutomatonState> to;
}
```

---


## Code Generation (3)


```cpp
// states s0,s1,s2
auto s0 = std::make_shared<FiniteAutomatonState>();
auto s1 = std::make_shared<FiniteAutomatonState>();
auto s2 = std::make_shared<FiniteAutomatonState>();

// fa object with s0 as initial state
auto fa = std::make_unique<FiniteAutomaton>(s0);

// add transitions s0->s1 and s1->s2
s0.transitions.emplace(('a' /*min*/, 'z' /*max*/, s1);
s1.transitions.emplace('0' /*min*/, '9' /*max*/, s2);

s2.accept = true; // s2 is final state
fa.deterministic = true;

```


<div class="center">

   ![height:100](images/cg1.png)

</div>

---
## Code Generation (4)

```cpp
bool traverse(FiniteAutomaton* fa, char* s, int slen) {
  auto p = fa->initial_state;
  for (int i = 0; i < slen; i++) {
    auto q = p.next(s[i]);
    if (q == nullptr)
      return false;
    if (q->accept) return true;
    p = q;
  }
  return false;
}

```


<div class="center">

   ![height:100](images/cg1.png)

</div>

---

## Code Generation (5)

```cpp
bool traverse(const char* str, unsigned int n) {
  unsigned int idx = 0;
  unsigned char c;
s0:
  if (idx >= n) return false;
  c = str[idx++];
  if (c >= 97 && c <= 122) goto s1;
  return false;
s1:
  if (idx >= n) return false;
  c = str[idx++];
  if (c >= 48 && c <= 57) return true;
  return false;
}

```


<div class="center">

   ![height:100](images/cg1.png)

</div>

---

## Code Generation (6)

<div class="center">

   ![height:620](images/cfg.png)

</div>

---

## Code Generation (7)
- LLVM Optimizations ⟶ Different Levels ⟶ O2 middle ground.

<div class="lcode">

```llvm
define i1 @traverse(i8* %0, i32 %1) {
entry:
  %2 = icmp eq i32 %1, 0
  br i1 %2, label %common.ret, label %bounds_cont
common.ret:
  %common.ret.op = phi i1 [ false, %entry ], [ false, %bounds_cont ], [ %8, %bounds_cont2 ]
  ret i1 %common.ret.op
bounds_cont:
  %3 = load i8, i8* %0, align 1
  %.off = add i8 %3, -97
  %4 = icmp ugt i8 %.off, 25
  %5 = icmp eq i32 %1, 1
  %or.cond = select i1 %4, i1 true, i1 %5
  br i1 %or.cond, label %common.ret, label %bounds_cont2
bounds_cont2:
  %6 = getelementptr i8, i8* %0, i64 1
  %7 = load i8, i8* %6, align 1
  %.off4 = add i8 %7, -48
  %8 = icmp ult i8 %.off4, 10
  br label %common.ret
}
```

</div>

---

## Unicode (1)

- Concepts: **Codepoint** , **Codeunit**, **UTF**.
- Two UTF Modes: UTF-32 & UTF-8.
- UTF-32: Fixed width, easier but wasteful.
- UTF-8: Variable width, 1-4 bytes/codepoint, trickier but more performant. 

---

## Unicode (2)

- UTF-32: Matching on whole codepoint. (e.g., **£**)
<div class="center">

   ![height:50](images/utf32fa.png)
   
</div>

- Need extra function calls to get the codepoint.

<div class="lcode">

```cpp
inline unsigned int nextCodepoint(const char* str, unsigned& idx) {
  unsigned c = 0;
  unsigned byteLen = getLength(str[idx]); // get number of utf-8 bytes
  c = readMultiByte(str, idx, byteLen); // read full code point
  idx += byteLen;
  return c;
}
bool traverse(const char * str, unsigned int n) {
  unsigned int idx = 0;
  unsigned int c; // (1) 32-bit integer
  s0:
    if (idx >= n) return false;
    c = nextCodepoint(str, idx); // (2) complex call
    if (c == 0xA3) return true; /*sterling pound codepoint*/
  return false;
}
```

</div>

---

## Unicode (3)

- UTF-8: Embeded Decoding inside DFA.
- Example: **9␣£**
   - Bytes: (**0x39 0x20 0xC2 0xA3**)


<div class="center">

   ![height:80](images/utf8fa.png)
   
</div>

---

## Unicode (4)
- UTF-8 Character Ranges.
- Example: **[U+0000 - U+FFFF]**.
![](images/bmpr.png)
- Algorithm by Andrew Gallant [3].

![bg right h:85%](images/bmp.png)

---
## SIMD Matcher
- Literals are common and easier to match.
- Implementation
   - Only for sub-string matches.
   - Fast Identification of *potential* matches.
   - Two SIMD algorithms: EPSMa [4] (m ≤ 16) and Generic Algorithm [5].

---

## EPSMa
- Example: 32-bit registers, 8-bit chars.
- Pattern: **ab**, Text: **xyab**.
![](images/epsm.png)

---

## Generic Algorithm
- Example: 64-bit registers, 8-bit chars.
- Pattern: **foo**, Text: **hellofoo**.

<div class="center"> 

   ![height:400](images/gsimd.png)

</div>


---

## Compilation Time Evaluation (1)
:::columns
- Ten patterns extracted from RegexLib [6].
   ![](images/ctpats1.png)
- LLVM **9x** Speedup over C++.
- UTF-32 Slightly faster than UTF-8.

<div class="right">
   
   ![](images/evrlib.png)

</div>
:::

---

## Compilation Time Evaluation (2)
:::columns
- 524 Patterns scraped from Github.
![](images/patgh.png)

- LLVM **9x** Speedup over C++.
- UTF-32 Perfomance degrades ⟶ Unicode patterns.

<div class="right">
   
   ![](images/evghb.png)

</div>
:::

---

## Evaluation (Engines)

- Our Implementation: (2 backends, 2 encoding modes).
- Google RE2 [7].
- PCRE2 (with JIT) [8].
- Boost Regex (C++ stdlib) [9].
---

## Evaluation (TPC-H)

:::columns
- Q13: **%special%packages%**.
- 1.5 Million rows - 15k matches.

- **1.1x** Speedup over PCRE.
- **2x** Speedup over RE2.

<div class="right">
   
   ![](images/ev1.png)

</div>
:::

---

## Evaluation (RegexRedux)
- RE2 and PCRE2 are the fastest. (Slowdown factor **4x** for our impl)
- Low number of matches ⟶ Character skip optimizations.
- UTF-32 Faster than UTF-8.

<div class="center">

  ![](images/ev2.png)

</div>

---

## Evaluation (LogBenchmark)
- Loghub Dataset.
![](images/loghubds.png)
- 4 patterns, 32 Million rows.

---

## Evaluation (LogBenchmark)

<div class="center">

  ![](images/ev3.png)

</div>

---

## Evaluation (LogBenchmark)

<div class="center">

  ![](images/rawlogs.png)

</div>

---

## Future Work
- DFA Minimization.
- Pattern Decomposition.
- Full Unicode Support.
- POSIX Regex Features.
- Adaptive Compilation.
---


<div class="center last">
  
  # Thank You
  ## Questions?

</div>

---

## References

1. [Firebird SQL](https://www.firebirdsql.org/file/documentation/html/en/refdocs/fblangref40/firebird-40-language-reference.html#fblangref40-commons-syntaxregex).
2. Aho, A. V., Lam, M. S., Sethi, R., & Ullman, J. D. (2007). Compilers. Pearson/Addison Wesley.
3. [https://github.com/BurntSushi/utf8-ranges](https://github.com/BurntSushi/utf8-ranges).
4. Faro, S., & Külekci, M. O. (2014). Fast and flexible packed string matching. Journal of Discrete Algorithms, 28, 61–72. https://doi.org/10.1016/j.jda.2014.07.003
5. [http://0x80.pl/articles/simd-strfind.html#algorithm-1-generic-simd](http://0x80.pl/articles/simd-strfind.html#algorithm-1-generic-simd).
6. [https://regexlib.com/](https://regexlib.com/).

---

## References

7. [https://github.com/google/re2](https://github.com/google/re2).
8. [https://www.pcre.org/current/doc/html/](https://www.pcre.org/current/doc/html/).
9. [https://www.boost.org/doc/libs/1_79_0/libs/regex/doc/html/index.html](https://www.boost.org/doc/libs/1_79_0/libs/regex/doc/html/index.html).
10. Hofbauer, M., Bachhuber, C., Kuhn, C., & Steinbach, E. (2022, Μάιος). Teaching Software Engineering As Programming Over Time. IEEE/ACM 4th International Workshop on Software Engineering Education for the Next Generation, 1–8. Virtual Event.
