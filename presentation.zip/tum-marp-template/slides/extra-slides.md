---
title: Efficient Code Generation for Regular Expressions
description: Efficient Code Generation for Regular Expressions
_class:
  - lead
footer: Efficient Code Generation for Regular Expressions | Mohamed Elzarei
_footer: ""
paginate: true
_paginate: false
marp: true
inlineSVG: false
auto-scaling: false

---

# Efficient Code Generation for Regular Expressions

Supervisor: Prof. Dr. Thomas Neumann

Advisor: M.Sc. Philipp Fent

Mohamed Elzarei

---

## Parser

- Generated Parser by ANTLR4.
- SQL-Compliant based on Firebird [1].

<div class="center">

![height:400](images/parsetree.png)

</div> 

---

## DFA Generator

<div class="center">

![width:250px](images/dfasa.png)

</div>

---
## Regular Expression to NFA (2)

1. Concatenation (e.g., **abc**) <br />
   ![width:700](images/tc5.png)
2. Alternation (e.g., **a|x**, **[ax]**) <br />
   ![width:400](images/tc4.png)
---

## Regular Expression to NFA (4)

3. Character Classes Ranges (e.g., **[a-z]**)
   ![width:350](images/ccr.png) <br />

4. Kleene Star (e.g., **a\***) ⟶ zero or more.
   ![width:350](images/tc10.png)

5. Plus Quantifier (e.g., **a+**) ⟶ Equivalent to **aa\*** ⟶ one or more.
6. Optional Quantifier (e.g., **a?**) ⟶ zero or one. <br />
   ![width:350](images/tc9.png)
---

## Regular Expression to NFA (3)

3. Negative Character Classes (e.g., **[^ax]**)
   equivalent to **(_ & (~[ax]))** <br />

   - Cross Product to get intersection.

   <br />

   :::columns
   ![width:400](images/tc6.png) <br />
   ![width:400](images/tc7.png)

   ![width:600](images/tc8.png)
   :::
---

## NFA to DFA (2)

- Modifications
   - No Epsilon ⟶ Removed during NFA Construction.
   - *Transitions are ranges* ⟶ Converted to non overlapping segments.

:::columns
![height:250](images/nfadfa3.png)

![height:350](images/nfadfa4.png)
:::

---

## DFA Minimization
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

- **Unreachable states** : Not reachable from start state.
- **Dead States** : No final state is reachable from this state.
- **Nondistinguishable states** ⟶ cannot be distinguished from one another for input.

---

## Code Generation (2)

```cpp
class FiniteAutomaton {
    public:
        bool deterministic;
        std::shared_ptr<FiniteAutomatonState> initial_state;
}
class FiniteAutomatonState {
    public:
        uint32_t id;
        bool accept;
        std::unordered_set<FiniteAutomatonTransition> transitions;
}
class FiniteAutomatonTransition {
    public:
        uint32_t min, max;
        std::shared_ptr<FiniteAutomatonState> to;
}
```

---

## Code Generation (3)


```cpp
// states s0,s1,s2
auto s0 = std::make_shared<FiniteAutomatonState>();
auto s1 = std::make_shared<FiniteAutomatonState>();
auto s2 = std::make_shared<FiniteAutomatonState>();

// fa object with s0 as initial state
auto fa = std::make_unique<FiniteAutomaton>(s0);

// add transitions s0->s1 and s1->s2
s0.transitions.emplace(('a' /*min*/, 'z' /*max*/, s1);
s1.transitions.emplace('0' /*min*/, '9' /*max*/, s2);

s2.accept = true; // s2 is final state
fa.deterministic = true;

```


<div class="center">

   ![height:100](images/cg1.png)

</div>


---

## Code Generation (CPP)

```cpp
bool traverse(FiniteAutomaton* fa, char* s, int slen) {
  auto p = fa->initial_state;
  for (int i = 0; i < slen; i++) {
    auto q = p.next(s[i]);
    if (q == nullptr)
      return false;
    if (q->accept) return true;
    p = q;
  }
  return false;
}

```

<div class="center">

   ![height:100](images/cg1.png)

</div>


---

## Unicode (4)
- UTF-8 Character Ranges.
- Example: **[U+0000 - U+FFFF]**.
![](images/bmpr.png)
- Algorithm by Andrew Gallant [3].

![bg right h:85%](images/bmp.png)

---

## EPSMa
- Example: 32-bit registers, 8-bit chars.
- Pattern: **ab**, Text: **xyab**.
![](images/epsm.png)

---

## Generic Algorithm
- Example: 64-bit registers, 8-bit chars.
- Pattern: **foo**, Text: **hellofoo**.

<div class="center"> 

   ![height:400](images/gsimd.png)

</div>

---
## Compilation Time Evaluation (1)
:::columns
- Ten patterns extracted from RegexLib [4].
   ![](images/ctpats1.png)
- LLVM **9x** Speedup over C++.
- UTF-32 Slightly faster than UTF-8.

<div class="right">
   
   ![](images/evrlib.png)

</div>
:::

---