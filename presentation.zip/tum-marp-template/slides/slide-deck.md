---
title: Efficient Code Generation for Regular Expressions
description: Efficient Code Generation for Regular Expressions
_class:
  - lead
footer: Efficient Code Generation for Regular Expressions | Mohamed Elzarei
_footer: ""
paginate: true
_paginate: false
marp: true
inlineSVG: false
auto-scaling: false
---

# Efficient Code Generation for Regular Expressions

Supervisor: Prof. Dr. Thomas Neumann

Advisor: M.Sc. Philipp Fent

Mohamed Elzarei

---

## Outline

- Introduction
- Implementation
- Evaluation
- Future Work

---

## Introduction

- Regular Expressions.
   - Many data-intensive applications: NLP, Graphs and Data Mining.
* Regular Expressions Engines
   - Compile RegExp to an internal representation.
   - DFA vs Backtracking.
   - Most are interpreted engines ⟶ Memory Indirection, Data not kept in CPU registers.
* Code-generation
   - Large Datasets ⟶ Amortizes the costs of compilation.
* Research Question ⟶ Can a code-generating RegExp Matching engine be performant?
   - Prototype DFA Based Engine.
---

## System Architecture

- Modular Architecture.
- CLI to interact with engine.

![bg right:50% 80%](images/sa.png)

---

## DFA Generator

---
## Regular Expression to NFA (1)

:::columns

- Thompson’s construction Algorithm [1].
- Set of rules for conversion of each sub-expression.
   - Literals (e.g., **a**).
   - Concatentaion (e.g., **ab**).
   - Alternation (e.g., **a|b**).
   - Kleene Star (e.g., **a\***).
      - Plus Quantifier (e.g., **a+** ⟶ **aa\***).
      - Optional Quantifier (e.g., **a?**).

![](images/parsetree.png)
:::

---

## Regular Expression to NFA (2)

1. Character Classes Ranges (e.g., **[a-z]**)
   ![width:350](images/ccr.png) <br />

2. Counting Quantifier (e.g., **a{1,3}**)
    ⟶ Duplicate each sub-automaton ⟶ Can lead to explosion of states. <br /><br />

   ![width:800](images/tc13.png)

---
## Regular Expression to NFA (3)

3. Negative Character Classes (e.g., **[^ax]**)
   equivalent to **(_ & (~[ax]))** <br />

   - Cross Product to get intersection.

   <br />

   :::columns
   ![width:400](images/tc6.png) <br />
   ![width:400](images/tc7.png)

   ![width:600](images/tc8.png)
   :::
---

## NFA to DFA
:::columns
- Powerset Construction Algorithm.
- Problem ⟶ State Explosion ⟶ $O(2^n)$ states.
- Example: **xyz|xya**.

![](images/nfatodfa1.png) <br />
![](images/nfatodfa2.png)
:::

---

## Code Generation

---
## Code Generation

- DFA ⟶ Code ⟶ Efficient Machine Code (LLVM JIT Compiler).
- Two backends: C++ and LLVM.
   - C++: Easy to write & debug.
   - LLVM: Much Faster Compilation.

---

## Code Generation (CPP)
- Clang ⟶ LLVM IR ⟶ JIT.
```cpp
bool traverse(const char* str, unsigned int n) {
  unsigned int idx = 0;
  unsigned char c;
s0:
  if (idx >= n) return false;
  c = str[idx++];
  if (c >= 97 && c <= 122) goto s1;
  return false;
s1:
  if (idx >= n) return false;
  c = str[idx++];
  if (c >= 48 && c <= 57) return true;
  return false;
}

```

<div class="center">

   ![height:90](images/cg1.png)

</div>

---


## Code Generation (LLVM)

<div class="center">

   ![height:620](images/cfg.png)

</div>

---

## Code Generation (LLVM Optimizations)
- LLVM Optimizations ⟶ Different Levels ⟶ O2 middle ground.

<div class="lcode">

```llvm
define i1 @traverse(i8* %0, i32 %1) {
entry:
  %2 = icmp eq i32 %1, 0
  br i1 %2, label %common.ret, label %bounds_cont
common.ret:
  %common.ret.op = phi i1 [ false, %entry ], [ false, %bounds_cont ], [ %8, %bounds_cont2 ]
  ret i1 %common.ret.op
bounds_cont:
  %3 = load i8, i8* %0, align 1
  %.off = add i8 %3, -97
  %4 = icmp ugt i8 %.off, 25
  %5 = icmp eq i32 %1, 1
  %or.cond = select i1 %4, i1 true, i1 %5
  br i1 %or.cond, label %common.ret, label %bounds_cont2
bounds_cont2:
  %6 = getelementptr i8, i8* %0, i64 1
  %7 = load i8, i8* %6, align 1
  %.off4 = add i8 %7, -48
  %8 = icmp ult i8 %.off4, 10
  br label %common.ret
}
```

</div>

---
## Unicode
---

## Unicode (1)
- Why Unicode?
- Pattern and Input text are UTF-8.
- Two UTF Modes: UTF-32 & UTF-8.
- UTF-32: Fixed width, easier but wasteful.
- UTF-8: Variable width, 1-4 bytes/codepoint, trickier but more performant. 

---

## Unicode (2)

- UTF-32: Matching on whole codepoint. (e.g., **£**)
<div class="center">

   ![height:50](images/utf32fa.png)
   
</div>

- Need extra function calls to get the codepoint.

<div class="lcode">

```cpp
inline unsigned int nextCodepoint(const char* str, unsigned& idx) {
  unsigned c = 0;
  unsigned byteLen = getLength(str[idx]); // get number of utf-8 bytes
  c = readMultiByte(str, idx, byteLen); // read full code point
  idx += byteLen;
  return c;
}
bool traverse(const char * str, unsigned int n) {
  unsigned int idx = 0;
  unsigned int c; // (1) 32-bit integer
  s0:
    if (idx >= n) return false;
    c = nextCodepoint(str, idx); // (2) complex call
    if (c == 0xA3) return true; /*sterling pound codepoint*/
  return false;
}
```

</div>

---

## Unicode (3)

- UTF-8: Embeded Decoding inside DFA.
- Example: **9␣£**
   - Bytes: (**0x39 0x20 0xC2 0xA3**)


<div class="center">

   ![height:80](images/utf8fa.png)
   
</div>

---

## Unicode (4)
- UTF-8 Character Ranges.
- Example: **[U+0000 - U+FFFF]**.
![](images/bmpr.png)
- Algorithm by Andrew Gallant [8].

![bg right h:85%](images/bmp.png)


---
## SIMD Matcher
- Literals are common and easier to match.
- Implementation
   - Only for sub-string matches.
   - Fast Identification of *potential* matches.
   - Two SIMD algorithms: EPSMa [2] (m ≤ 16) and Generic Algorithm [3].

---
## Evaluation
---

## Compilation Time Evaluation
:::columns
- 524 Patterns scraped from Github.
![](images/patgh.png)

- LLVM **9x** Speedup over C++.
- UTF-32 Perfomance degrades ⟶ Unicode patterns.

<div class="right">
   
   ![](images/evghb.png)

</div>
:::

---

## Evaluation (Engines)

- Our Implementation: (2 backends, 2 encoding modes).
- Google RE2 [5].
- PCRE2 (with JIT) [6].
- Boost Regex (C++ stdlib) [7].
---

## Evaluation (TPC-H)

:::columns
- Q13: **%special%packages%**.
- 1.5 Million rows - 15k matches.

- **1.1x** Speedup over PCRE.
- **2x** Speedup over RE2.

<div class="right">
   
   ![](images/ev1.png)

</div>
:::

---

## Evaluation (RegexRedux)
- RE2 and PCRE2 are the fastest. (Slowdown factor **4x** for our impl)
- Low number of matches ⟶ Character skip optimizations.
- UTF-32 Faster than UTF-8.

<div class="center">

  ![](images/ev2.png)

</div>

---

## Evaluation (LogBenchmark)
- Loghub Dataset.
- 4 patterns, 32 Million rows.

![](images/loghubds.png)

---

## Evaluation (LogBenchmark)

<div class="center">

  ![](images/ev3.png)

</div>

---

## Evaluation (LogBenchmark)

<div class="center">

  ![](images/rawlogs.png)

</div>

---

## Future Work
- DFA Minimization.
- Pattern Decomposition.
- POSIX Regex Features.
---


<div class="center last">
  
  # Thank You
  ## Questions?

</div>

---

## References

1. Aho, A. V., Lam, M. S., Sethi, R., & Ullman, J. D. (2007). Compilers. Pearson/Addison Wesley.
2. Faro, S., & Külekci, M. O. (2014). Fast and flexible packed string matching. Journal of Discrete Algorithms, 28, 61–72. https://doi.org/10.1016/j.jda.2014.07.003
3. [http://0x80.pl/articles/simd-strfind.html#algorithm-1-generic-simd](http://0x80.pl/articles/simd-strfind.html#algorithm-1-generic-simd).
4. [https://regexlib.com/](https://regexlib.com/).

---

## References

5. [https://github.com/google/re2](https://github.com/google/re2).
6. [https://www.pcre.org/current/doc/html/](https://www.pcre.org/current/doc/html/).
7. [https://www.boost.org/doc/libs/1_79_0/libs/regex/doc/html/index.html](https://www.boost.org/doc/libs/1_79_0/libs/regex/doc/html/index.html).
8. [https://github.com/BurntSushi/utf8-ranges](https://github.com/BurntSushi/utf8-ranges).
9. Hofbauer, M., Bachhuber, C., Kuhn, C., & Steinbach, E. (2022, Μάιος). Teaching Software Engineering As Programming Over Time. IEEE/ACM 4th International Workshop on Software Engineering Education for the Next Generation, 1–8. Virtual Event.
